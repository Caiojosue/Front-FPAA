<template>
  <footer class="bottom-0 w-full bg-blue-600 text-white py-6 text-center ">
    <p class="text-sm">
      {{ new Date().getFullYear() }} Desenvolvido por Alunos - UNIMAR
    </p>
    <p class="text-xs mt-2">Igor, Rafael, Caio, Caue e Cesar</p>
  </footer>
</template>
